#####################################
# R TUTORIAL 4 : Econometrics
#####################################

# ----------- Environment ---------------
library(dplyr)
library(ggplot2)
library(gridExtra)



# Path
rm(list = ls())
path <- '.../Tuto4'
path_input <- paste0(path, '/1_inputs/')
path_output <- paste0(path, '/2_outputs/')






# --------- Monte Carlo --------


sizes <- c(500, 1000, 2000, 10000)

thMean <- 2
plots <- list()

for(size in sizes){
  sample <- rnorm(size, mean = thMean, sd = 10)
  cumulative_means <- cumsum(sample) / (1:size)
  p <- ggplot() +
    geom_line(
      data = data.frame(ind = 1:size, cMeans = cumulative_means),
      aes(x=ind, y = cMeans),
      color = 'darkcyan') +
    geom_hline(yintercept = thMean, color = 'brown', linetype = 'dashed')
  plots <- append(plots, list(p))
}

grid.arrange(grobs = plots, ncol = 2)



# --------------------- Econometrics---------------------------
# Import data
data <- read.csv(paste0(path_input, '/04_202308_cps.csv'))

data %>%
  mutate(
    hatEarnings = alpha + beta*hours
  )%>%
  ggplot() +
  geom_point(aes(x = hours, y = (earnings)), alpha = .8, color = 'grey') +
  geom_point(aes(x=hours, y = (hatEarnings)), color = "darkred")+
  geom_line(aes(x=hours, y = (hatEarnings)), color = "darkcyan")


# -- Sampling -- 
# Get three disbalanced samples and perform regression
d1 <- sample_n(data, size = 500, weight = hours)
d2 <- sample_n(data, size = 300, weight = hourrt)
d3 <- sample_n(data, size = 200, weight = earnings)

d1$sample <- "Sample 1"
d2$sample <- "Sample 2"
d3$sample <- "Sample 3"

d <- bind_rows(d1, d2, d3)

d %>% ggplot(aes(x = hours, y = earnings, color = sample)) +
  geom_point(alpha = .5) +
  geom_smooth(method = 'lm', formula= y ~ x, se = F) +
  scale_color_manual(values = c('darkred', 'darkcyan', 'darkgrey')) +
  theme_minimal()



# -- Coefficients computation
# Function to compute the betas and alphas for the regression of Earnings on Hours for each sample:
computeCoefficients <- function(data, Y, X){
   #In: The data you will use the Y and X of your regression
  b <- cov(data[Y], data[X])/var(data[X])
  a <- mean(data[[Y]]) - b*mean(data[[X]])
  res <- t(data.frame(c(a, b)))
  colnames(res) <- c('alpha', 'beta')
  return(res)
}

computeCoefficients(d1, "earnings", "hours")
computeCoefficients(d2, "earnings", "hours")
computeCoefficients(d3, "earnings", "hours")


# -- Simple regressions --


reg1 <- lm(earnings ~hours, data)
sum1 <- summary(reg1)

# Plotting residuals

data.frame(res = reg1$residuals) %>%
  ggplot(aes(x = res)) +
  geom_density(color = 'darkcyan', fill = 'darkcyan', alpha = .2, linewidth = 1)+
  geom_vline(xintercept = 0, linetype = 'dashed', color = 'darkred', linewidth = .8) +
  theme_minimal()


sumData <- data %>% group_by(sex) %>% summarize(m.grp = mean(earnings, na.rm = T))

data %>% 
  ggplot(aes(x = earnings, fill = sex, color = sex)) +
  geom_density(alpha = .2) +
  scale_color_manual(values = c('darkred', 'darkcyan')) +
  scale_fill_manual(values = c('darkred', 'darkcyan')) +
  geom_vline(data = sumData, aes(xintercept = m.grp, color = sex), linewidth = .6, linetype = 'dashed')+
  geom_label(data = sumData,
            aes(x = m.grp + (-1)^(sex=="Female")*300,
                y = 0.00075,
                label = as.character(round(m.grp, 1))),
            color = 'white', 
            fontface = 'bold')



# -- Engineering some variables -- 
data <- data %>%
  mutate(
    sexNum = ifelse(sex=='Male', 1, 0)
  )

reg2 <- lm(earnings ~ sex, data)
summary(reg2)

reg3 <- lm(earnings ~ sexNum, data)
summary(reg3)

reg4 <- lm(earnings ~ educ, data)
summary(reg4)


# Re-order data with factors
data <- data %>%
  mutate(
    educf = relevel(as.factor(educ), ref = "No high school")
  )


# -- Multivariate regressions
multiReg <- lm(earnings ~ sex + educf + hours, data)
summary(multiReg)

# Log of earnings
data <- data %>% mutate(
  logEarnings = log(earnings)
)

multiRegLog <- lm(logEarnings ~ sex + educf + hours, data)
summary(multiRegLog)



