#####################################
# R TUTORIAL 2 : Data visualisation
#####################################

# ----------- Environment ---------------
library(dplyr)
library(ggplot2)



# Path
path <- 'C:/Users/C09581/Desktop/R tutorials'
path_input <- paste0(path, '/1_inputs/')
path_output <- paste0(path, '/2_outputs/')

# Import data
wid <- read.csv(paste0(path_input, 'wid.csv'))
gdp <- read.csv(paste0(path_input, 'gdp.csv'))
View(wid)
View(gdp) # Bad columns naming (to me at least)


# ---------- Cleaning and tyding -----------------
# Renaming columns
colnames(gdp)
colnames(gdp) <- c(
  'year',
  'yearCode',
  'country',
  'countryCode',
  'gdp')
View(gdp)

# Another possibility for renaming columns
gdp2 <- gdp %>% rename(
  c('year' = 'Time')
)


# -------------- Merging -----------------
# Look at the different components of the identifier
unique(gdp$country)
unique(wid$country)

"Sao Tome and Principe" %in% gdp$country # Is this character string in thje gpd$country column ?

# Let's check length of different vectors
length(intersect(gdp$country, wid$country))
length(unique(gdp$country))
length(unique(wid$country))


# Let's left_join the gdp on our wid database
# Identifier country x year

jwid <- wid %>%
  left_join(gdp %>% select(c(country, year, gdp)), by = c('country', 'year'))
# Does not work, there is a type problem !


# Updated type
jwid <- wid %>%
  mutate(year = as.character(year)) %>%
  left_join(gdp %>% select(c(country, year, gdp)), by = c('country', 'year'))


# ------------- Plotting --------------------
wid %>%
  filter(country %in% c('Algeria')) %>%
  ggplot(aes(x = year, y = fshare, color = country)) +
  geom_line()


wid %>%
  filter(continent == 'Africa', year == '2013') %>%
  ggplot(aes(x = inc_head)) +
  geom_histogram()


wid %>%
  filter(continent == 'Africa', year == '2013') %>%
  ggplot(aes(x = inc_head)) +
  geom_histogram(bins = 100, color = 'blue', fill = 'red')


wid %>%
  ggplot(aes(x = inc_head, y = top1)) +
  geom_point() +
  xlab("Income per adult") +
  ylab("Income share among top 1%") +
  ylim(0.2, 0.3)


wid %>%
  ggplot(aes(x = inc_head, y = top1)) +
  geom_point() +
  xlab(NULL) +
  ylab(NULL) +
  xlim(0, 50000)


wid %>%
  ggplot(aes(x = inc_head, y = top1)) +
  geom_point() +
  xlab(NULL) +
  ylab(NULL) +
  xlim(0, 50000) +
  theme(
    panel.grid.major = element_line(colour = 'blue'),
    panel.background = element_blank()
  )

# Let's create a dataframe with random overvations around 0
df <- data.frame(x = rnorm(15000), y = rnorm(15000))
plot_base <- df %>% ggplot(aes(x = x, y = y))


plot_base +  geom_point() # A bit shady

plot_base + geom_point(size = .2) # We see better

plot_base + geom_point(shape = 'x') # Not really

plot_base + geom_point(shape = 'x', alpha = .5) # A little transparency


# Big difference
wid %>%
  ggplot(aes(x = inc_head, y = top1, color = continent)) +
  geom_point() # between this


wid %>%
  ggplot(aes(x = inc_head, y = top1)) +
  geom_point(color = 'blue') # and this



wid %>%
  ggplot(aes(x = inc_head, y = top1, color = fshare)) +
  geom_point(alpha = .4) 


wid %>%
  ggplot(aes(x = inc_head, y = top1)) +
  geom_point() +
  facet_wrap(~continent)



wid %>%
  ggplot(aes(x = inc_head, y = top1)) +
  geom_point() +
  facet_wrap(
    ~continent,
    ncol = 6,
    scale = 'free_x'
    )


# Adding layers
bl <- read.csv(paste0(path_input, '02_playfair-balance.csv'))

bl %>%
  ggplot() +
  geom_line(aes(x = year, y = imports, color = 'Imports')) +
  geom_line(aes(x = year, y = exports, color = 'Exports')) +
  scale_color_manual(values = c('brown','darkgreen')) +
  ylab('')




bl_plot <- bl %>% ggplot() +
  geom_line(aes(x = year, y = imports, color = 'Imports')) +
  geom_line(aes(x =  year, y = exports, color = 'Exports')) +
  scale_color_manual(values = c('brown', 'darkgreen')) +
  ylab(NULL)

# Text I want to print for some years only
some_years <- bl %>% filter(year %in% c(1702, 1740, 1764))

# Ad them to the plot
bl_plot +
  geom_point(data = some_years,
             aes(x = year, y = exports)) +
  geom_text(
    data = some_years,
    aes(x = year, y = exports, label = exports),
    nudge_y = 4,
    nudge_x = -2
  )

  